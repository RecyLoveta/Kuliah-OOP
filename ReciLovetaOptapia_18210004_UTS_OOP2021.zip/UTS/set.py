data=(1,1,1,1,1,1,2,2,2,3)
print (data)
listdata=[1,1,1,1,1,1,2,2,2,2,3]
print (listdata)
print (set(listdata))